local tr = aegisub.gettext

script_name = tr"ASS WE CAN"
script_description = tr"注入灵魂"
script_author = "晨轩°"
script_version = "1.1.1"

-- 载入re库 正则表达
local re = require 'aegisub.re' 
clipboard = require 'aegisub.clipboard'
local Yutils = require("Yutils")


-- 辅助支持表
local default_config = {
	debug = {
		level = 4
	}
}
cx_Aeg_Lua = {
	debug = {
		-- 调试输出定义
		-- 设置调试输出等级
		level = default_config.debug.level
		-- 修改调试输出等级(0~5 设置大于5的等级时不会输出任何信息,设置值小于0时会被置0)
		,changelevel = function (level)
			if type(level) ~= 'number' then error('错误的调试等级设置！',2) end
			if level < 0 then level = 0 end
			cx_Aeg_Lua.debug.level = level
		end
		-- 普通输出(带换行、不带换行)
		,println = function (msg)
			if cx_Aeg_Lua.debug.level > 5 then return end
			if msg ~= nil then 
				aegisub.debug.out(cx_Aeg_Lua.debug.level, tostring(msg).."\n") 
			else
				aegisub.debug.out(cx_Aeg_Lua.debug.level, "\n")
			end
		end
		,print = function (msg)
			if cx_Aeg_Lua.debug.level > 5 then return end
			if msg == nil then return end
			aegisub.debug.out(cx_Aeg_Lua.debug.level, tostring(msg))
		end

		-- 输出一个变量的字符串表示
		,var_export = function (value)
			aegisub.debug.out(cx_Aeg_Lua.debug.level, '('..type(value)..')'..tostring(value)..'\n')
		end
		-- 直接输出一个表达式结构信息
		,var_dump = function (value)
			-- print覆盖
			local function print(msg)
				cx_Aeg_Lua.debug.println(msg)
			end
			-- 好用的table输出函数
			local function print_r(t)
				local print_r_cache={}
				local function sub_print_r(t,indent)
					if (print_r_cache[tostring(t)]) then
						print(indent.."*"..tostring(t))
					else
						print_r_cache[tostring(t)]=true
						if (type(t)=="table") then
							for pos,val in pairs(t) do
								if (type(val)=="table") then
									print(indent.."["..pos.."] => "..tostring(t).." {")
									sub_print_r(val,indent..string.rep(" ",string.len(pos)+8))
									print(indent..string.rep(" ",string.len(pos)+6).."}")
								elseif (type(val)=="string") then
									print(indent.."["..pos..'] => "'..val..'"')
								else
									print(indent.."["..pos.."] => "..tostring(val))
								end
							end
						else
							print(indent..tostring(t))
						end
					end
				end
				if (type(t)=="table") then
					print(tostring(t).." {")
					sub_print_r(t,"  ")
					print("}")
				else
					sub_print_r(t,"  ")
				end
				print()
			end
			-- 运行函数
			print_r(value)
			-- 打印结果
			
		end

	}
	,display = {
		-- 显示一个简单的提示窗口，参数(提示信息[,类型标识[,默认值]])
		--[[ 类型标识(返回类型)：
				0-提示框(nil)，提示需要每行尽可能短(不超过9个字)
				1-确认取消框(bool)
				2-单行文本输入框(string or nil)
				3-单行整数输入框(number or nil)
				4-单行小数输入框(number or nil)
			注意：整数与小数输入有误时不会限制或报错，可能得到奇怪的结果。
		]]
		confirm = function (msg,type_num,default)
			local config = {} -- 窗口配置
			local result = nil -- 返回结果
			local buttons  = nil
			local button_ids = nil
			if type(msg) ~= 'string' then
				error('display.confirm参数错误-1，提示信息必须存在且为文本类型！',2)
			end
			if type_num == nil then type_num = 0 end
			if type(type_num) ~= 'number' then
				-- db.var_export(type_num)
				error('display.confirm参数错误-2，类型标识必须是数值！',2)
			end
			
			if type_num == 0 then
				config = {
					{class="label", label=msg, x=0, y=0,width=8}
				}
				buttons = {'OK!'}
				button_ids = {ok = 'OK!'}
			elseif type_num == 1 then
				config = {
					{class="label", label=msg, x=0, y=0,width=12}
				}
			elseif type_num == 2 then
				if default == nil then default = '' end
				config = {
					{class="label", label=msg, x=0, y=0,width=12},
					{class="edit", name='text',text=tostring(default), x=0, y=1,width=12}
				}
			elseif type_num == 3 then
				if default == nil then default = 0 end
				if type(type_num) ~= 'number' then
					error('display.confirm参数错误-3，此标识的默认值必须为数值！',2)
				end
				config = {
					{class="label", label=msg, x=0, y=0,width=12},
					{class="intedit", name='int',value=default, x=0, y=1,width=12}
				}
			elseif type_num == 4 then
				if default == nil then default = 0 end
				if type(type_num) ~= 'number' then
					error('display.confirm参数错误-3，此标识的默认值必须为数值！',2)
				end
				config = {
					{class="label", label=msg, x=0, y=0,width=12},
					{class="floatedit", name='float',value=default, x=0, y=1,width=12}
				}
			else
				error('display.confirm参数错误，无效的类型标识！',2)
			end
			
			-- 显示对话框
			btn, btnresult = aegisub.dialog.display(config,buttons,button_ids)

			-- 处理并返回结果
			if type_num == 0 then
				result = nil
			elseif type_num == 1 then
				if btn ~= false then
					result = true
				else
					result = false
				end
			elseif type_num == 2 then
				if btn ~= false then
					result = btnresult.text
				end
			elseif type_num == 3 then
				if btn ~= false then
					result = btnresult.int
				end
			elseif type_num == 4 then
				if btn ~= false then
					result = btnresult.float
				end
			end
			-- debug.var_export(result)
			return result
		end

	}
}


debug = cx_Aeg_Lua.debug
display = cx_Aeg_Lua.display

-- table表的copy函数(来自Yutils)
function table.copy(t, depth)
	-- Check argument
	if type(t) ~= "table" or depth ~= nil and not(type(depth) == "number" and depth >= 1) then
		error("table and optional depth expected", 2)
	end
	-- Copy & return
	local function copy_recursive(old_t)
		local new_t = {}
		for key, value in pairs(old_t) do
			new_t[key] = type(value) == "table" and copy_recursive(value) or value
		end
		return new_t
	end
	local function copy_recursive_n(old_t, depth)
		local new_t = {}
		for key, value in pairs(old_t) do
			new_t[key] = type(value) == "table" and depth >= 2 and copy_recursive_n(value, depth-1) or value
		end
		return new_t
	end
	return depth and copy_recursive_n(t, depth) or copy_recursive(t)
end

-- 清除前后空格
local str_trim_expr_pre = re.compile([[^\s+]],re.NOSUB,re.NO_MOD_M)
local str_trim_expr_end = re.compile([[\s+$]],re.NOSUB,re.NO_MOD_M)
function str_trim(str)
	out_str, rep_count = str_trim_expr_pre:sub(str,'')
	out_str, rep_count1 = str_trim_expr_end:sub(out_str,'')
	if not rep_count then rep_count = 0 end
	if not rep_count1 then rep_count1 = 0 end
	rep_count = rep_count + rep_count1
	return out_str, rep_count
end

-- 生成ASSline-字幕行(style,text,start_time,end_time)
function toASSLine(style_ ,text_,start_time_,end_time_ ,comment_)
	if style_ == nil then style_ = 'Default' end
	if text_ == nil then text_ = '' end
	if start_time_ == nil then start_time_ = 0 end
	if end_time_ == nil then end_time_ = 0 end
	if comment_ == nil then comment_ = false end
	return 	{
			class = "dialogue",
			raw = "",
			section = "[Events]",
			comment = comment_,
			layer = 0,
			start_time = start_time_,
			end_time = end_time_,
			style = style_,
			actor = '',
			margin_t = 0,
			margin_b = 0,
			margin_l = 0,
			margin_r = 0,
			margin_v = nil,
			effect = 'LTA',
			text = text_,
			extra = {}
	}
end

-- 处理LRC文件 并返回处理好的数组
function FileDeal_Lrc(filepath)
	file,msg = io.open(file_name,'r')
	if file == nil then 
		aegisub.debug.out(2, "文件\"%s\"打开失败！\n信息：%s\n",file_name,msg)
		aegisub.cancel()
	end
	io.input(file)
	text = io.read()
	if text == nil then
		aegisub.debug.out(2, "错误：此文件为空。")
		aegisub.cancel()
	end
	--[[
	LRC行规范
	class:行类别(Attributes-属性、lyrics-歌词行、unknown-未知行)
	
	通用
		pos:处于文件的第几行
		source:行原文
	
	Attributes类
		key:属性的键
		value:属性的值
		
	lyrics类
		relatively:相对位置(从1开始)
		start_time:行起始时间(ms)
		end_time:行结束时间(ms)
		text:行内容
	
	unknown类
		无通用属性外的属性
		
	]]
	-- Attributes类
	LRC_expr_attr = re.compile("^\\[([^0-9]{1}[\\S\\s]*):([\\S\\s]*)\\]$")
	-- lyrics类
	LRC_expr_lyr = re.compile("^\\[(\\d{1,2}):(\\d{1,2}).(\\d{1,3})\\]([\\s\\S]*)")
	-- ]]
	LRC_lines = {}
	cout = 0 -- 循环计数
	lyr_cout = 0 -- 歌词行计数
	while text ~= nil do
		cout = cout + 1
		if cout > 1000 then
			if not display.confirm('当前文件过大，请检查',1) then 
				-- 如果选择取消
				aegisub.progress.task('选择取消')
				aegisub.cancel()
			end
		end
		
		if text ~= '' then
			text = str_trim(text)
			res_attr = LRC_expr_attr:match(text)
			res_lyr = LRC_expr_lyr:match(text)
			line = {pos = cout}
			if res_attr ~= nil and res_lyr == nil then
				-- 仅res_attr有结果
				line.class = 'Attributes'
				line.source = res_attr[1].str
				line.key = res_attr[2].str
				line.value = res_attr[3].str
			else	
				if res_attr == nil and res_lyr ~= nil then
					-- 仅res_lyr有结果
					lyr_cout = lyr_cout + 1
					line.class = 'lyrics'
					line.source = res_lyr[1].str
					line.relatively = lyr_cout
					if #res_lyr[4].str == 3 then
						line.start_time = res_lyr[2].str*60000 + res_lyr[3].str*1000 + res_lyr[4].str
					else
						line.start_time = res_lyr[2].str*60000 + res_lyr[3].str*1000 + res_lyr[4].str*10
					end
					line.end_time = line.start_time + 2000
					line.text = res_lyr[5].str
					if #LRC_lines > 0 then
						-- 同步间隔
						LRC_lines[#LRC_lines].end_time = line.start_time
					end
				else
					line.class = 'unknown'
					line.source = text
					-- 其他情况
				end
			end
			table.insert(LRC_lines,line)
			-- debug.var_dump(line)
			-- debug.var_dump(res_attr)
			-- debug.var_dump(res_lyr)
			
		end
		text = io.read()
	end
	-- debug.var_dump(LRC_lines)
	return LRC_lines
end

-- 处理LRC行数组                     
function Deal_LRC_lines(LRC_lines,active_line,subs)
	start_time = nil -- 歌词第一句开始时间
	change_time = 0 -- 改变到的开始时间(默认为0)

	-- 获取活动行信息
	if active_line ~= nil then
		-- 查询时间
		change_time = subs[active_line].start_time
	end
	
	for i = 1,#LRC_lines do
		if LRC_lines[i].class == 'lyrics' then
			if start_time == nil then 
				-- 对齐首行
				start_time = LRC_lines[i].start_time
				change_time = change_time - start_time
			end
			-- 时间操作
			LRC_lines[i].start_time = LRC_lines[i].start_time + change_time
			LRC_lines[i].end_time = LRC_lines[i].end_time + change_time
		end
	end
	
	-- 然后 时间就对齐好了
	-- 哈↑哈↑哈↑哈↑哈↑
	return LRC_lines
end

-- LRC_lines 打包成 字幕行对象
function LRC_Lines_To_subs_Dialogue(LRC_lines,active_line,subs)
	--[[
	字幕行模版
	
	]]
	start_time = 0
	lrc_style = 'Default' -- 新增歌词对应样式，默认default
	if active_line ~= nil then
		-- 查询时间
		start_time = subs[active_line].start_time
		-- 查询样式
		lrc_style = subs[active_line].style
	end
	add_subs = {}
	
	for i=1,#LRC_lines do
		
		if i == 1 then
			table.insert(add_subs,toASSLine(nil,'-----------------',start_time,start_time,true))
		end
		
		if LRC_lines[i].class == 'lyrics' then

			table.insert(add_subs,toASSLine(lrc_style,LRC_lines[i].text,LRC_lines[i].start_time,LRC_lines[i].end_time))
		end
		
		if i == #LRC_lines then
			table.insert(add_subs,toASSLine(nil,'-----------------',start_time,start_time,true))
		end
	end
	return add_subs
end


-- ASS载入
-- ASS文件载入
function open_ASS_file(subs,file_name)
	file,msg = io.open(file_name,'r')
	if file == nil then 
		aegisub.debug.out(2, "文件\"%s\"打开失败！\n信息：%s\n",file_name,msg)
		aegisub.cancel()
	end
	io.input(file)
	-- 读取字幕元信息
	text = io.read()
	cout = 0
	-- 存储字幕头部信息
	head = ""
	-- 创建空解析器
	PARSER = Yutils.ass.create_parser()
	while text ~= nil do
		cout = cout + 1
		if cout > 1000 then
			aegisub.debug.out(2, "错误，读取超过一千行未结束字幕元信息读取\n")
			aegisub.debug.out(2, "此文件可能不是ASS格式的字幕文件！\n")
			io.close(file)
			aegisub.cancel()
		end
		-- 添加解析
		PARSER.parse_line(text)
		-- 获取正确解析的字幕行信息
		dialogs = PARSER.dialogs()
		-- 查看是否有读取到字幕
		if dialogs.n ~= 0 then
			-- 已读取到至少一行的字幕信息
			-- 重建解析器并跳出元信息读取循环
			PARSER = Yutils.ass.create_parser(head)
			break
		end
		head = head..text.."\n"
		text = io.read()
	end
	aegisub.progress.set(10)
	debug.println('读取:'..'元信息解析完毕，解析行数:'..cout)
	-- 判断是否真的读取成功
	if text == nil then 
		aegisub.debug.out(2, "因未知原因，此字幕文件读取失败！")
		io.close(file)
		aegisub.cancel()
	end
	debug.println('读取:'..'清除旧的字幕')
	-- 清除旧的字幕
	aegisub.progress.task("删除旧行")
	aegisub.progress.set(30)
	clear_ASS(subs)
	-- 载入分辨率以及文件标题(如果存在)
	aegisub.progress.task('载入分辨率')
	debug.println('读取:'..'载入分辨率')
	Yutils_meta_deal(subs,head)
	
	-- 载入样式
	aegisub.progress.task('载入样式')
	debug.println('读取:'..'载入样式')
	Yutils_styles_deal(subs,PARSER.styles())
	aegisub.progress.set(40)
	
	-- 读取字幕行
	aegisub.progress.task('读取字幕行')
	debug.println('读取:'..'读取字幕行')
	cout = 0
	while text ~= nil do
		cout = cout + 1
		debug.println('读取:'..'正在读取 '..cout..' 行')
		aegisub.progress.set(((cout % 100000)/2000)+40)
		if cout % 100000 == 0 then
			aegisub.progress.task('已读取：'..math.floor(cout / 100000)..'万行')
		end
		-- 解析行
		seccess_type = PARSER.parse_line(text)
		-- debug.println('读取:'..'解析行→'..text)
		
		if not seccess_type and text ~= '' then
			aegisub.debug.out(2, "解析到%d行时出现错误，此行无法解析！\n",cout)
			aegisub.debug.out(2, "解析失败行:%s\n",text)
			-- io.close(file)
			-- aegisub.cancel()
		end


		if cout % 1000 == 0 then 
			debug.println('读取:'..'触发转换第 '..(cout / 1000)..' 次')
			-- 每一千行转换并置入一次字幕
			Yutils_dialogs_deal(subs,PARSER.dialogs())
			-- 重建解析器
			PARSER = nil
			PARSER = Yutils.ass.create_parser(head)
			-- aegisub.cancel()
		end

		text = io.read()
	end
	aegisub.progress.set(90)
	-- 转换剩余行
	aegisub.progress.task('最终解析')
	debug.println('读取:'..'触发结束转换')
	-- debug.var_dump(PARSER.dialogs())
	Yutils_dialogs_deal(subs,PARSER.dialogs())
	-- 释放解析器空间
	debug.println('读取:'..'释放解析器空间')
	PARSER = nil
	-- 关闭文件
	io.close(file)
	debug.println('读取:'..'读取完毕，共载入 '..cout..' 行字幕')
	aegisub.progress.set(100)
end


-- 菜单的选择启动函数

-- LRC变轴
function macro_LrcToAss(subs, selected_lines, active_line)
	-- 修改全局提示等级
	debug.changelevel(3)
	-- 歌词选择
	cf_title = '选择歌词文件，不满意时善用撤销'
	cf_wildcards = '歌词LRC文件(.lrc)|*.lrc|所有文件(*)|*'
	file_name = aegisub.dialog.open(cf_title, '', '', cf_wildcards, false, true)
	if not file_name then
		-- 如果未选择文件
		debug.println("取消操作...")
		aegisub.progress.task('选择取消')
		aegisub.cancel()
	end
	-- 文件处理
	LRC_lines = FileDeal_Lrc(file_name)
	-- LRC行处理
	LRC_lines = Deal_LRC_lines(LRC_lines,active_line,subs)
	-- LRC行打包
	add_subs = LRC_Lines_To_subs_Dialogue(LRC_lines,active_line,subs)
	-- LRC行插入
	start_line_num = active_line
	if active_line == nil then
		for i=1,#subs do
			if subs[i].class == 'dialogue' then
				start_line_num = i
				break;
			end
		end
	end
	new_selected = {}
	-- 正式插入
	for i=1,#add_subs do
		subs.insert(start_line_num + i - 1, add_subs[i])
		new_selected[0] = start_line_num + i
	end
	if #new_selected ~= 0 then
		return new_selected
	end
	return 
end

-- 双语歌词(直接填充)
function macro_Ass1TO2_1Y_clip(subs, selected_lines, active_line)
	--debug.changelevel(3)
	text = clipboard.get()
	if text == nil then
		display.confirm('剪贴板内容不是文本！',0)
		aegisub.cancel()
	end
	text = str_trim(text)
	if text == '' then
		display.confirm('剪贴板无内容！',0)
		aegisub.cancel()
	end
	
	chunks = re.split(text, '\n')
	--debug.println(text)
	--debug.var_dump(chunks)
	acl_line = subs[active_line]
	acl = active_line
	new_select = {}
	-- 前期准备大致完成
	subs.insert(acl + #chunks,toASSLine(nil,"-----------------",acl_line.start_time,acl_line.start_time,true))
	for i=1,#chunks do
		line = subs[acl + i - 1]
		if line.class ~= 'dialogue' then
			aegisub.debug.out(2, '所选行范围内存在异常行，请联系作者。')
			aegisub.cancel()
		end
		line.text = str_trim(chunks[i])
		line.effect = "LTA_12"
		subs.insert(acl + #chunks + i,line)
		table.insert(new_select,acl + #chunks + i)
	end
	subs.insert(acl + 2*#chunks + 1,toASSLine(nil,"-----------------",acl_line.start_time,acl_line.start_time,true))
	--debug.var_dump(new_select)
	return new_select
end
-- 双语歌词(对照填充)
function macro_Ass1TO2_2Y_clip(subs, selected_lines, active_line)

	text = clipboard.get()
	if text == nil then
		display.confirm('剪贴板内容不是文本！',0)
		aegisub.cancel()
	end
	text = str_trim(text)
	if text == '' then
		display.confirm('剪贴板无内容！',0)
		aegisub.cancel()
	end
	if selected_lines == nil or #selected_lines < 1 then
		display.confirm('没有选择需要匹配的行',0)
		aegisub.cancel()
	end
	chunks = re.split(text, '\n')
	acl_line = subs[active_line]
	acl = active_line
	new_select = {}
	-- 第一阶段完成
	--[[
	Bilingual_lyrics
	{
		A = "",
		B = ""
	}
	
	
	]]
	Bilingual_lyrics = {}
	ls = {}
	for i=1,#chunks do
		text = str_trim(chunks[i])
		if text ~= '' then
			table.insert(ls,text)
		end
	end
	-- 最大匹配行数
	max_lines = #chunks
	chunks = nil
	if #ls%2 ~= 0 then
		display.confirm('剪贴板行数不为偶数！',0)
		aegisub.cancel()
	end
	for i=1,#ls/2 do
		table.insert(Bilingual_lyrics,{A=ls[2*i - 1],B=ls[2*i]})
	end
	ls = nil
	expr = re.compile([[(\{[\s\S]+?\}){1}]],re.NOSUB)
	expr1 = re.compile([[[^\s]{1}]],re.NOSUB)
	-- 第二阶段完成
	add_subs = {}
	
	table.insert(add_subs,toASSLine(nil,"-----------------",acl_line.start_time,acl_line.start_time,true))
	for i=1,#selected_lines do
		line = subs[selected_lines[i]]
		if line.class ~= 'dialogue' then
			aegisub.debug.out(2, '所选行范围内存在异常行，请联系作者。')
			aegisub.cancel()
		end
		-- 如果途中出现注释行、带特效标签的行、特效不为空的行则取消更改
		result = expr:match(line.text)
		if not result and not line.comment and line.effect == '' then
			line.effect = "LTA_12"
			line.text = str_trim(line.text)
			if line.text ~= '' then
				-- 匹配行数
				for j=1,#Bilingual_lyrics do
					if Bilingual_lyrics[j].A == line.text then
						line.text = Bilingual_lyrics[j].B
						break
					end
					if j == #Bilingual_lyrics then
						line.effect = "LTA_12_*"
					end
				end

			end
			table.insert(add_subs,line)	
		else
			aegisub.debug.out(2, "操作失败！\n更改范围内存在注释行、带特效标签的行或特效不为空，请自行检查")
			aegisub.cancel()
		end
	end
	table.insert(add_subs,toASSLine(nil,"-----------------",acl_line.start_time,acl_line.start_time,true))
	-- 第三阶段完
	-- 置入字幕，确定新的选择行
	slln = selected_lines[#selected_lines]
	for i=1,#add_subs do
		subs.insert(slln + i,add_subs[i])
		table.insert(new_select,slln + i)
	end
	return new_select
end



-- 转换Yutils解析的行为ASS兼容行，参数(Yutils的解析行)，返回转换后的行
function conversion_YtoA_line(Yutils_line)
	ASS_line = Yutils_line
	ASS_line.class = "dialogue"
	ASS_line.raw = ""
	ASS_line.section = "[Events]"
	ASS_line.margin_t = ASS_line.margin_v
	ASS_line.margin_b = ASS_line.margin_v
	ASS_line.margin_v = nil
	ASS_line.extra = {}
	return ASS_line
end
-- 将Yutils解析出来的行添加到当前所选字幕行之后
function Yutils_dialogs_deal(subs,dialogs,active_line)
	if aegisub.progress.is_cancelled() then 
		aegisub.cancel()
	end
	acl_line = subs[active_line]
	time_change = subs[active_line].start_time
	acl = active_line + 1
	for i=1,#dialogs do
		line = conversion_YtoA_line(dialogs[i])
		if i == 1 then 
			time_change = time_change - line.start_time
		end
		line.start_time = line.start_time + time_change
		line.end_time = line.end_time + time_change

		-- 插入处理好的行
		subs.insert(acl,line)
		-- debug.print('添加行:'..'正在添加')
		-- debug.var_dump(line)
		acl = acl + 1
	end
	if str_trim(acl_line.text) == '' then
		acl_line.comment = true
		subs[active_line] = acl_line
	end
end


function macro_AssMove(subs, selected_lines, active_line)
	head = [[
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
]]
	text = clipboard.get()
	if type(text) ~= 'string' then
		display.confirm('剪贴板内容不是文本！',0)
		aegisub.cancel()
	end
	text = str_trim(text)
	if text == '' then
		display.confirm('剪贴板无内容！',0)
		aegisub.cancel()
	end
	-- 创建解析器，并解析此文本
	PARSER = Yutils.ass.create_parser(head..text)
	debug.println('解析行→'..text)
	
	if not PARSER then
		aegisub.debug.out(2, '解析失败！无法识别剪贴板内容！')
		aegisub.debug.out(2, "解析失败文本:%s\n",text)
		-- io.close(file)
		-- aegisub.cancel()
	end
	Yutils_dialogs_deal(subs,PARSER.dialogs(),active_line)
	
end

function macro_AssFull(subs, selected_lines, active_line)
	--debug.changelevel(3)
	text = clipboard.get()
	if text == nil then
		display.confirm('剪贴板内容不是文本！',0)
		aegisub.cancel()
	end
	text = str_trim(text)
	if text == '' then
		display.confirm('剪贴板无内容！',0)
		aegisub.cancel()
	end
	
	chunks = re.split(text, '\n')

	-- 前期准备大致完成
	check = true
	acl = active_line
	for i=1,#chunks do
		line = subs[acl+i-1]
		if line.class ~= 'dialogue' then
			aegisub.debug.out(2, '所选行范围内存在异常行，请联系作者。')
			aegisub.cancel()
		end
		if check and str_trim(line.text) ~= '' then
			if not display.confirm('检测到当前所选行范围存在内容，是否继续？',1) then 
				-- 如果选择取消
				aegisub.progress.task('选择取消')
				aegisub.cancel()
			end
			check = false
		end
		line.text = str_trim(chunks[i])
		subs[acl+i-1] = line
	end
	
	
end

function macro_AssFull_noblank(subs, selected_lines, active_line)
	--debug.changelevel(3)
	text = clipboard.get()
	if text == nil then
		display.confirm('剪贴板内容不是文本！',0)
		aegisub.cancel()
	end
	text = str_trim(text)
	if text == '' then
		display.confirm('剪贴板无内容！',0)
		aegisub.cancel()
	end
	
	chunks_pre = re.split(text, '\n')
	chunks = {}
	for i=1,#chunks_pre do
		chunks_pre[i] = str_trim(chunks_pre[i])
		if chunks_pre[i] ~= '' then
			table.insert(chunks,chunks_pre[i])
		end
	end
	-- 前期准备大致完成
	check = true
	acl = active_line
	for i=1,#chunks do
		line = subs[acl+i-1]
		if line.class ~= 'dialogue' then
			aegisub.debug.out(2, '所选行范围内存在异常行，请联系作者。')
			aegisub.cancel()
		end
		if check and str_trim(line.text) ~= '' then
			if not display.confirm('检测到当前所选行范围存在内容，是否继续？',1) then 
				-- 如果选择取消
				aegisub.progress.task('选择取消')
				aegisub.cancel()
			end
			check = false
		end
		line.text = str_trim(chunks[i])
		subs[acl+i-1] = line
	end
	
	
end


function macro_AssTextGet(subs, selected_lines, active_line)
	if selected_lines == nil or #selected_lines == 0 then
		display.confirm('没有选择或其他错误！',0)
		aegisub.cancel()
	end
	set_text = nil
	for i = 1,#selected_lines do
		line = subs[selected_lines[i]]
		if line.class ~= 'dialogue' then
			aegisub.debug.out(2, '所选行范围内存在异常行，请联系作者。')
			aegisub.cancel()
		end
		if set_text then
			set_text = set_text .. "\n" .. line.text
		else
			set_text = line.text
		end
		
	end

	if clipboard.set(set_text) then
		display.confirm("所选行的内容已置入剪贴板\n您可以在任意处粘贴",0)
	else
		aegisub.debug.out(2, '设置内容至剪切板时出现错误！')
		aegisub.debug.out(2, "以下是提取到的内容：\n%s",set_text)
	end
end

function macro_about()
	-- 修改全局提示等级
	debug.changelevel(1)
	version_log = [[
1.0.0 Alpha 2020-1-20
·它出生了(歌轴助手)
·增加了歌轴专用技能(lrc变轴等)

1.1.0 Alpha 2020-1-29
·改名：轴man特攻(划掉)，二度更名 ASS WE CAN
·增加了快速移轴功能(麻麻再也不用担心轴移位了)
·增加了快速填轴功能(麻麻再也不用担心填轴太麻烦了)

1.1.1 2020-1-29
·正式版，打包出库.jpg

↑更新日志↑
]]
	msg = version_log.."\n\n"..'轴man特攻 '..script_version.."\n"..
[[

歌词lrc转实轴：选择一行，此行开始时间将作为歌轴起始时间参考，无选择时从零开始
↑说明↑
助手功能总览：
1.通过解析歌词lrc，将LRC转换成轴
2.检测当前所选择的轴位置自动调整歌词时间
3.解析双语的歌词翻译 自动将轴双行并置入翻译或原文
```歌词lrc下载推荐页面：http://music.wandhi.com
4.快速移轴 快速平移轴到指定位置
5.快速填充 根据剪贴板内容快速填充
注：本助手大部分功能使用剪贴板完成，敬请留意
注：本助手的提示等级为level 4 如果不能正常显示信息或者其他异常请检查您的设置
注：本插件所做修改可由AEG的撤销功能撤回
作者：晨轩°(QQ3309003591)
本关于的最后修改时间：2020年1月29日
感谢您的使用！
]]
	debug.println(msg)
end

function macro_can_use()
	if Yutils == nil then
		return false
	end
	return true
end


-- 注册AEG菜单
aegisub.register_macro(script_name.."/歌轴/LRC 变轴！", '请选择与确定首行开始时间', macro_LrcToAss, macro_can_use)
aegisub.register_macro(script_name.."/歌轴/对照填充(重复行)", '读取剪贴板内容，重复匹配到的行并填充内容', macro_Ass1TO2_2Y_clip, macro_can_use)
aegisub.register_macro(script_name.."/歌轴/直接填充(重复行)", '读取剪贴板内容，重复匹配到的行并填充内容', macro_Ass1TO2_1Y_clip, macro_can_use)
aegisub.register_macro(script_name.."/提取所选行文本", '选择需要提取文本的行，选择此项，文本将放置至剪切板内', macro_AssTextGet, macro_can_use)
aegisub.register_macro(script_name.."/快速移轴", '剪切需要移动的轴，选中定位行，然后选择此选项', macro_AssMove, macro_can_use)
aegisub.register_macro(script_name.."/快速填充", '复制或剪切需要填充的文本，选中填充开始轴，然后选择此选项', macro_AssFull, macro_can_use)
aegisub.register_macro(script_name.."/快速填充(忽略空行)", '复制或剪切需要填充的文本，选中填充开始轴，然后选择此选项', macro_AssFull_noblank, macro_can_use)
aegisub.register_macro(script_name.."/关于", script_description, macro_about, macro_can_use)




